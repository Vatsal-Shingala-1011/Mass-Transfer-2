clc
close all
clear

ln_nL =[20 17 12 7 2.8 0.8 -4.2 -7.5 -10 -14 -16];

L= [0.0 0.25 0.5 0.75 1.25 2.5 5 7.5 10 12.5 15];
% L = L.*10000

plot(L,ln_nL,'o');
hold on;
p1 = polyfit(L(4:11),ln_nL(4:11),1);
f1 = polyval(p1,L(4:11));
plot(L(4:11),f1);

slope = (f1(8)-f1(4))/(L(8)-L(4))

syms x y
[a,intercept] = vpasolve([y==poly2sym(p1),x==0],[x,y])

n0 = exp(intercept)