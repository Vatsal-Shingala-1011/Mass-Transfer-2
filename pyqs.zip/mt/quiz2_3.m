clc
clear 
close all

% p = [15.6 31.74 59.6 99.97 29 479.2 679.1];
% q = [2.819 3.48 3.97 4.342 4.94 5.294 5.304];
% pq = p./q;
% figure(1)
% plot(p,pq,'o'); hold on; grid on;
% p1 = polyfit(p,pq,1);
% f1 = polyval(p1,p);
% plot(p,f1,Color='black')
% 
% 
% p1 = [27.2 53.2 99.97 244.8 424 617.1 803.2];
% q1 = [2.469 3.078 3.635 4.188 4.475 4.71 5.289];
% pq1 = p1./q1;
% figure(2)
% plot(p1,pq1,'o'); hold on; grid on;
% p11 = polyfit(p1,pq1,1);
% f11 = polyval(p11,p1);
% plot(p1,f11,Color='black')
% 
% 
% p2 = [21.07 45.33 93.34 279.2 461.9 634.3];
% q2 = [1.677 2.386 2.954 3.584 3.922 4.244];
% pq2 = p2./q2;
% figure(3)
% plot(p2,pq2,'o'); hold on; grid on;
% p12 = polyfit(p2,pq2,1);
% f12 = polyval(p12,p2);
% plot(p2,f12,Color='black')





Pv = 760;

x=p./Pv;

figure(1)
plot(x,q,'o')
xlabel("x")
ylabel("q")
title("X vs q (exp. and stimulated)")
hold on;
p1 = polyfit(x,q,1);
f1 = polyval(p1,x);

plot(x,f1);



% for intercept and slope:
syms x y
[a,b] = vpasolve(y==poly2sym(p1),x==0,[x,y])

intercept = b;

point1 = [0.2 polyval(p1,0.2)];

point2 = [0.5 polyval(p1,0.5)];
slope = (point2(2)-point1(2))/(point2(1)-point1(1))
syms c q
[c_prime, qm] = vpasolve([q==1/(slope*c),q==(c-1)/(c*Pv*intercept)],[c,q])



