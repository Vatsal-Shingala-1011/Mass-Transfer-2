clc
clear 
close all

 %% q2
p = [0.0126,0.0251,0.1,0.1995];
q = [0.794,1.41,5.62,11.2];
for i=1:length(q)
    q(i)=q(i)/100000;
    p(i)= log(p(i));
    q(i)= log(q(i));
end
% plot with given data
plot(p,q)
hold on;
p1 = polyfit(p,q,1);
f1 = polyval(p1,p);

% plot with fitted data
plot(p,f1);
title('Freundlich isotherm')

%syms x y
%[intercerpt, slope] = 

