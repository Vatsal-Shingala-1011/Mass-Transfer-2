clc
clear
close all

%% Step 1

B = [0.04 0.05 0.07 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 0.993 1];
C = [0 0.11 0.26 0.375 0.474 0.487 0.468 0.423 0.356 0.274 0.185 0.09 0.001 0];

tiexc = [0.1 0.245 0.426];
tiexb = [0.048 0.065 0.133];
tieyc = [0.098 0.242 0.409];
tieyb = [0.891 0.736 0.523];
lt = length(tiexc);
slope_tie = zeros(1,lt);
figure(1)
plot(B,C,'b',LineWidth=1)
hold on;
grid on;
plot([0 1 0 0],[0 0 1 0],'k-.','linewidth',1.25)
xlabel('xB');ylabel('xC,yC');title('interpolated data - overall process schematic')

for i = 1:lt
slope_tie(i) = (tieyc(i)-tiexc(i))/((tieyb(i)-tiexb(i)));
plot([tiexb(i) tieyb(i)],[tiexc(i) tieyc(i)]);
hold on;
end

B1 = zeros(1,10001);
C1 = zeros(1,10001);
for i = 1:10001
B1(i) = (i-1)/10000;
C1(i) = round(interp1(B,C, (i-1)/10000),4);
end


tiexb = zeros(1,length(tiexc));
tieyb = zeros(1,length(tiexc));
for i = 1:length(tiexc)
index1 = find(abs(C1-tiexc(i)) < 0.001,1,'first');
index2 =  find(abs(C1-tieyc(i)) < 0.001,1,'last');
XX = [B1(index1) B1(index2)] ;
YY = [tiexc(i) tieyc(i)];

plot(XX,YY,'mo:','linewidth',1.25);
end



%% Step 2 and 3



S=2500;
F=2000;

xbf= 0;
xcf=0.45;
ybs=1;
ycs=0;
M = F + S;
Mx = (F*xbf + S*ybs)/M;
My = (F*xcf + S*ycs)/M;
plot(Mx,My,'bo')
text(Mx,My,' M')
plot([xbf ybs],[xcf ycs], 'g^-','linewidth',1.2,Color='magenta') % Line FS
text(xbf,xcf,' F')
text(ybs,ycs,' S')

Rnx = 0.04;
index1 = find(abs(C1-Rnx) < 0.001,1,'first');
XX = B1(index1);
YY = C1(index1);
plot(XX,YY,'mo:','linewidth',1.25);
text(XX,YY,' Rn')


p1 = polyfit(B(1:7),C(1:7),5);
f1 = polyval(p1,B(1:7));
plot(B(1:7),f1, 'm', 'linewidth',1.25,Color='black');grid on;


p2 = polyfit(B(7:14),C(7:14),3);
f2 = polyval(p2,B(7:14));
plot(B(7:14),f2, 'm', 'linewidth',1.25,Color='black');grid on;

%% step 4 and 5 - Plotting E1

syms x y
slope = ((My - YY)/(Mx-XX));
[E1x,E1y] = vpasolve([y == poly2sym(p2),y == My + slope*(x - Mx)],[x,y],[0 1; 0 1]);
plot((E1x),(E1y),'o')
text((E1x),(E1y),'    E1')
plot([XX, E1x],[YY, E1y],LineWidth=1.2,Color='magenta')

%% step 6 - locating delta point

% F - xbf,xcf , S- xcs,ycs , R - XX,YY  
slope_FE1 = ((E1y-xcf)/(E1x-xbf));
slope_RS = ((YY-ycs)/(XX-ybs));

syms x y
[delx,dely] = vpasolve([y==E1y + slope_FE1*(x-E1x),y==YY + slope_RS*(x-XX)],[x,y]);
plot((delx),(dely),'o')
text((delx),(dely),'D')
plot([xbf delx],[xcf dely],Color='cyan',LineWidth=1.2)
plot([XX delx],[YY dely],Color='cyan',LineWidth=1.2)


%% step 7 - R1

Ex = ones(1,100);
Ey = ones(1,100);
Rx = ones(1,100);
Ry = ones(1,100);
e=ones(1,100);
r=ones(1,100);

Ex(1) = E1x;
Ey(1) = E1y;
Ex(2) = E1x;
Ey(2) = E1y;
count = 2;

% known - F,S,Rn(XX,YY)
syms E del
[e(1),delta] = vpasolve([del == E - F,del == (E*E1y - F*xcf)/dely],[E,del]);


while Ry(count)>=0.04
   
if ((0 < Ey(count)) && (Ey(count) <= 0.098))
slope = 0 + (Ey(count) - 0)*slope_tie(1)/(0.098-0);
elseif((0.098< Ey(count)) && (Ey(count) <= 0.242))
slope = slope_tie(1) + (Ey(count) - 0.098)*slope_tie(2)/(0.242 - 0.098);
elseif ((0.242 < Ey(count)) && (Ey(count) <= 0.409))
slope = slope_tie(2) + (Ey(count) - 0.242)*slope_tie(3)/(0.409 - 0.242);
else
   slope = slope_tie(3) + (Ey(count)-0.409)*(-0.515)/(0.5-0.409);
end

syms x y
[Rx(count),Ry(count)] = vpasolve([y==poly2sym(p1),y==Ey(count) + slope*(x-Ex(count))],[x,y],[0 0.3; 0 0.6]);



if Ry(count)<=0.04
    break                                    
end                        

plot(Rx(count),Ry(count),'o')
text(Rx(count),Ry(count),' R')
plot([Rx(count) Ex(count)],[Ry(count) Ey(count)],LineWidth=1.5,Color='black')

plot([Rx(count) delx],[Ry(count) dely],Color='cyan',LineWidth=0.35)

slope_Rdel = ((Ry(count) - dely)/(Rx(count) - delx));



syms x y 
[Ex(count + 1),Ey(count + 1)] = vpasolve([y==poly2sym(p2),y== dely + slope_Rdel*(x-delx)],[x,y],[0.5 1; 0 0.5]);
plot(Ex(count+1),Ey(count+1),'o')
text(Ex(count+1),Ey(count+1),' E')

syms E R
[e(count),r(count-1)] = vpasolve([E == delta + R,E == (delta*dely + R*Ry(count))/Ey(count+1)],[E,R]);


count = count+1;
Ry(count) = Ry(count-1);

end

figure(2)
stage = [1,2,3];
plot(Ry(1:3),stage);
hold on;
plot(Ey(1:3),stage);


 disp('for a fraction of DPH of ')
 disp(0.04) 
 disp('No. of Stages: ');
        disp(count-2);
      





fr_dph_r(1) = (Ry(1)*r(1)-F*xcf)/(F*xcf);
% fr_dph_e(1) = Ey(1)*e(1)/(F*xcf);
