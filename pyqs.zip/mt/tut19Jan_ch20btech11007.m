clc
clear
close all

B = [0 0.004 0.006 0.01 0.02 0.03 0.036 0.07 0.13 0.16 0.19 0.23 0.26 0.5 0.63 0.71 0.78 0.84 0.9 0.95 1];
C = [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.4025 0.405 0.402 0.4 0.35 0.3 0.25 0.2 0.15 0.1 0.05 0];
A = 1 - B - C;
tiexc = [0.04 0.083 0.13 0.215 0.395];
tieyc = [0.035 0.068 0.09 0.145 0.31];


figure(1)
hold on;
p1 = polyfit(B(1:10),C(1:10),5);
f1 = polyval(p1,B(1:10));
plot(B(1:10),f1, 'm', 'linewidth',1.25,Color='black');grid on;
hold on;
p2 = polyfit(B(11:21),C(11:21),5);
f2 = polyval(p2,B(11:21));
plot(B(11:21),f2, 'm', 'linewidth',1.25,Color='black');grid on;

tiexb = zeros(length(tiexc));
tieyb = zeros(length(tiexc));


% intersection of fitted curve and tiexc
for i=1:length(tiexc)
    syms x y
    [a,b] = vpasolve([y==poly2sym(p1),y==tiexc(i)],[x,y],[0,1]);
    %tiexb(i)=a(2)
end

% intersection of fitted curve and tieyc
for i=1:length(tieyc)
    syms x y
    [c,d]=vpasolve([y==poly2sym(p2),y==tieyc(i)],[x,y],[0,1]);
    %tieyb(i) = a(2)
end

grid on;
hold on;
plot([0 1 0 0],[0 0 1 0], 'k-.', 'linewidth',1.25)
xlabel('xB,yB');ylabel('xC,yC');
title( 'Tutorial 19Jan');




%% Tie line slopes
