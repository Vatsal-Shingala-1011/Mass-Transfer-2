clc
clear
close all

clear;
clc;
close all;

B=[0.0008,0.0016,0.0024,0.0038,0.0058,0.0185,0.0418,0.089,0.378,0.378,0.53,0.61,0.6558,0.6915,0.7428,0.799,0.8828,0.9995];
C=[0,0.0502,0.1105,0.189,.255,0.361,0.4495,0.5320,0.49,0.49,0.4060,0.3505,0.3155,0.2860,0.2410,0.1895,0.1105,0];

%% q1

 B1 = B(1:9);
 B2 = B(10:18);
 
 C1 = C(1:9);
C2 = C(10:18);
% 
% 
 figure(1)
 plot(B1,C1,'bo-',Color='green',LineWidth=1.5);
% 
hold on;
 plot(B2,C2,'bo-',Color='green',LineWidth=1.5);
% 
 grid on;
 hold on;
 plot([0 1 0 0],[0 0 1 0], 'k-.', 'linewidth',1.25)
 hold on;
 %plot([0 0.95],[0.5 0.05], 'linewidth',1.25) % Line FS
 xlabel('xB,yB');ylabel('xC,yC');
 title( 'MIDSEM');
 
 
 A = 1-B-C;
 p1 = polyfit(B1,C1,5);
 f1 = polyval(p1,B1);
 plot(B1,f1, 'm', 'linewidth',1.25,Color='blue');grid on;
% 
% 
 p2 = polyfit(B2,C2,3);
 f2 = polyval(p2,B2);
 plot(B2,f2, 'm', 'linewidth',1.25,Color='blue');grid on;


 %% q2

 F = 2000;
 xcf = 0.5;
 xbf = 0;
%  S = 2000;
 ycs = 0;
 ybs = 1;


 figure(2)


 %% q3

 figure(3)
 plot(B,C,'bo-',Color='green',LineWidth=1.5);
 hold on;

 plot([0 1 0 0],[0 0 1 0], 'k-.', 'linewidth',1.25)
 hold on;

 grid on;
 tiexc = [C(3) C(5) C(7)];
tiexb = [B(3) B(5) B(7)];
tieyc = [C(16) C(14) C(12)];
tieyb = [B(16) B(14) B(12)];

lt = length(tiexc);
tie_slope = zeros(1,lt);

for i = 1:lt
tie_slope(i) = (tieyc(i)-tiexc(i))/((tieyb(i)-tiexb(i)));
plot([tiexb(i) tieyb(i)],[tiexc(i) tieyc(i)],Color='red');
hold on;
end

%% q4-d

% M = F + S;
% Mx = (F*xbf + S*ybs)/M;
% My = (F*xcf + S*ycs)/M;
% plot(Mx,My,'bo')
% text(Mx,My,' M')
plot([xbf ybs],[xcf ycs], 'g^-','linewidth',1.2,Color='magenta') % Line FS
text(xbf,xcf,' F')
text(ybs,ycs,' S')


%% q6-f - continued

stages = 100;
r = ones(1,stages);
e = ones(1,stages);
xbr = ones(1,stages);
xcr = ones(1,stages);
ybe = ones(1,stages);
yce = ones(1,stages);
M = ones(1, stages);
S = ones(1, stages);
Mx = ones(1,stages);
My = ones(1, stages);
solute_fraction = ones(1,stages);

S(1) = 2000;
for i=1:stages
  M(i) = F + S(i);
Mx(i) = (F*xbf + S(i)*ybs)/M(i);
My(i) = (F*xcf + S(i)*ycs)/M(i);
plot(Mx(i),My(i),'o',Color='black') 
text(Mx,My,' M')



if ((0 < My(i)) && (My(i) <= tiexc(1)))
slope = 0 + (My(i) - 0)*tie_slope(1)/(tiexc(1));
elseif((tiexc(1)< My(i)) && (My(i) <= tiexc(2)))
slope = tie_slope(1) + (My(i) - tiexc(1))*tie_slope(2)/(tiexc(2) - tiexc(1));
elseif ((tiexc(2) < My(i)) && (My(i) <= tiexc(3)))
slope = tie_slope(2) + (My(i) - tiexc(2))*tie_slope(3)/(tiexc(3) - tiexc(2));
elseif ((tiexc(3) < My(i)) && (My(i) <= 0.5))
slope = tie_slope(3) + (My(i) - tiexc(3))*(-0.155)/(0.5 - tiexc(3));
end

syms x y
[A,B] = vpasolve([y==poly2sym(p1),y==My(i)+slope*(x-Mx(i))],[x,y],[0 0.5; 0 0.5]);
xbr(i)=A(2);
xcr(i)=B(2);
plot(xbr(i),xcr(i),'o',Color='black')
text(xbr(i),xcr(i),' R')

syms x y
[ybe(i),yce(i)] = vpasolve([y == poly2sym(p2),y == My(i) + slope*(x - Mx(i))],[x,y], [0.2 1; 0 0.405]);
plot(ybe(i),yce(i),'o',Color='black')
text(ybe(i),yce(i),'   E')

plot([xbr(i) ybe(i)],[xcr(i) yce(i)],Color='red',LineWidth=1.35)


syms E R
[e(i),r(i)] = vpasolve([E==M(i)-R,E==R*((My(i)-xcr(i))/(yce(i)-My(i)))],[E,R]);
%solute_fraction(i) = (yce(i)*e(i) - ycs*S)/(F*xcf)
F = r(i);
xbf=xbr(i);
xcf=xcr(i);
S(i+1) = r(i);

if xcr(i)<0.02
    break
end


end
disp("no.of stages:")
disp(i)

%% question-g
figure(5)
stage = ones(1,100);
for j =1:i
    stage(j) = j;
end
plot(stage(1:i),xcr(1:i),Color='red')
hold on;
plot(stage(1:i),yce(1:i),Color='black')
