clear;
clc;
close all;

xB= [0.004,0.006,0.01,0.02,0.03,0.036,0.07,0.13,0.26];
xC = [0.05,0.1,  0.15, 0.2, 0.25, 0.3, 0.375, 0.4, 0.4];
yB = [0.95, 0.9, 0.84, 0.78, 0.71, 0.63, 0.5, 0.26];
yC = [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4 ];
figure(1)

% Right-Angled Triangle
plot([0 1 0 0],[0 0 1 0], 'k-.', 'linewidth',1.25)
hold on;
% rafinnate and extract resp.
plot(xB,xC,'bo-',LineWidth=1.25,Color='cyan')
plot(yB,yC,'bo-',LineWidth=1.25,Color='green')
% values to check the fit
rafsol = 0:0.01:0.15;
extsol = 0.25:0.1:1;
% fit
p1 = polyfit(xB,xC,4);
p2 = polyfit(yB,yC,3);
f1 = polyval(p1,rafsol);
f2 = polyval(p2,extsol);

plot(rafsol,f1, 'm', 'linewidth',1.1,Color='black');grid on;
plot(extsol,f2, 'm', 'linewidth',1.1,Color='black');grid on;

% FS line
line([0.98 0],[0 0.35],Color='red')

% Tie lines
line([0.004 0.97],[0.04 0.035],Color='magenta')
line([0.0055 0.94],[0.083 0.068],Color='magenta')
line([0.009 0.91],[0.13 0.09],Color='magenta')
line([0.022 0.85],[0.215 0.145],Color='magenta')
line([0.12 0.61],[0.395 0.31],Color='magenta')




xlabel('xB,yB');ylabel('xC,yC');
title( 'Tutorial 2');