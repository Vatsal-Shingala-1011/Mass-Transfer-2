clc
close all
clear

% A- seawood B- hot water C- protein
% F- 0.481A, 0.49B, 0.029C : 400kg/h
% S- 1B, 0A, 0C : 500kg/h
% xc >= 0.002

% xa= [];

% xb= [];
% xc = 1- xa - xb;
% ya= [];
% yb= [];
% yc = 1- ya - yb;

%w - Extract : w_dash - Slurry

wA = [0.002 0.001 0.0 0.0 0.0 0.0];
wB = [0.952 0.967 0.979 0.989 0.994 0.998];
wC = [0.046 0.032 0.021 0.011 0.006 0.002];
wA_dash = [0.432 0.417 0.401 0.398 0.397 0.396];
wB_dash = [0.524 0.564 0.586 0.5954 0.5994 0.6028];
wC_dash = [0.026 0.019 0.013 0.0066 0.0036 0.0012];



xc = ones(1,length(wA));
Z = ones(1,length(wA));
yc = ones(1,length(wA));
z = ones(1,length(wA));



for i = 1:length(wA)
xc(i) = (wC_dash(i))/(wC_dash(i)+wB_dash(i));
Z(i) = (wA(i))/(wB(i)+wC(i));
yc(i) = (wC(i))/(wC(i)+wB(i));
z(i) = (wA_dash(i))/(wB_dash(i)+wC_dash(i));
end

figure(1)
plot(xc,z, 'm', 'linewidth',1.25,Color='blue'); grid on;
hold on;
plot(yc,Z,'m', 'linewidth',1.25,Color='green'); grid on;
hold on;

for j=1:length(wA_dash)

plot([xc(j) yc(j)],[z(j) Z(j)],'--ok',Color='magenta');
hold on;
end

F = 400;
S = 500;
zF = 48.1/(100-48.1);
zS = 0;
xcF=2.9/(100-48.1);
ycS = 0;
F_dash = F * (100-48.1)/100;
S_dash = S ;

plot(xcF,zF,'o');text(xcF,zF,'F');
hold on;


plot(ycS,zS,'o');text(ycS,zS,'S');
hold on;


plot([xcF,ycS],[zF,zS])
i=1;
%% 

L_dash = ones(1,100);
V_dash = ones(1,100);
Ly = ones(1,100);
Vy = ones(1,100);
while(xcF>=0.002)
    

disp(i)

M = (F_dash+S_dash);
xM = (F_dash*xcF + S_dash*ycS)/(M);
zM = (F_dash*zF + S_dash*zS)/(M);
plot(xM,zM,' o'); text(xM,zM,[' M'  num2str(i) ''])
p1 = polyfit(xc,z,2);
p2 = polyfit(yc,Z,1);
Ly(i) = polyval(p1, xM);
Vy(i) = polyval(p2, xM);

disp(Ly(i))
disp(Vy(i))

plot([xM xM],[Ly(i) Vy(i)], '--ok');
text(xM, Ly(i),['L' num2str(i) '']);
text(xM, Vy(i),['V' num2str(i) '']);

L_dash(i) = (M*(zM-Vy(i)))/(Ly(i)-Vy(i));
V_dash(i) = M-L_dash(i);

disp(L_dash(i))
disp(V_dash(i))

F_dash = L_dash(i);
xcF = xM;
zF = Ly(i);
plot([xcF,ycS],[zF,zS])



i=i+1;

end

stages = ones(1,100);
for j=1:i-1
    stages(j) = j;
end
figure(2)
plot(stages(1:j),Vy(1:j))
hold on;
plot(stages(1:j),Ly(1:j))
legend()
