clc
close all
clear

t= [0 0.25 0.5 0.75 1 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3 3.25 3.5 3.75 4 4.25 4.5 4.75 5 5.5 6 6.5 7.0 7.5 8.0];
W= [4.2 4.145 4.091 4.035 3.978 3.920 3.868 3.811 3.756 3.704 3.653 3.605 3.558 3.516 3.480 3.448 3.421 3.394 3.368 3.345 3.323 3.285 3.253 3.226 3.202 3.183 3.166];

n = length(t);
X = ones(1,n);
dXdt = ones(1,n-1);
N = ones(1,n-1);

for i=1:n
    X(i) = (W(i)-3)/3;
end
for i=1:n-1
    dXdt(i) = (X(i+1)-X(i))/(t(i+1)-t(i));
end

for i=1:n-1
    N(i) = (-W(i+1)/0.1)*(dXdt(i));
end
figure(1)
plot(t,X,'o')
xlabel("Time")
ylabel("Moisture Level")

figure(2)
plot(X(2:27),N,'o');hold on;
xlabel("Moisture Level")
ylabel("Drying Ratio")
hold on;

p1 = polyfit(X(2:9),N(1:8),1);
f1 = polyval(p1,X(2:9));
plot(X(2:9),f1,Color="red");
plot(0,polyval(p1,0),'o')
hold on;

p2 = polyfit(X(10:27),N(9:26),1);
f2 = polyval(p2,X(9:26));
plot(X(9:26),f2,Color="black");

hold on;

Y = ones(1,27);
for i=1:20
    Y(i)= 1/(polyval(p1,X(i+7))*X(i+7)+polyval(p2,X(i+7)));
end
figure(3)
plot(X,Y,'o')
xlabel("X")
ylabel("Yinv")




