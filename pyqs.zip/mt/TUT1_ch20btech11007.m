clear;
clc;
close all;

B=[0.0011,0.0021,0.0031,0.0058,0.0136,0.0372,0.1259,0.1376,0.1376,0.1508,0.3357,0.4751,0.608,0.7698,0.8872,0.9982];
C=[0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.6058,0.6058,0.6107,0.5919,0.4944,0.3748,0.2223,0.1079,0.0];


B1 = B(1:8);
B2 = B(9:16);

C1 = C(1:8);
C2 = C(9:16);


figure(1)
plot(B1,C1,'bo-',Color='green',LineWidth=1.5);

hold on;
plot(B2,C2,'bo-',Color='green',LineWidth=1.5);

grid on;
hold on;
plot([0 1 0 0],[0 0 1 0], 'k-.', 'linewidth',1.25)
hold on;
%plot([0 0.95],[0.5 0.05], 'linewidth',1.25) % Line FS
xlabel('xB,yB');ylabel('xC,yC');
title( 'Tutorial 2');


A = 1-B-C;
p1 = polyfit(B1,C1,5);
f1 = polyval(p1,B1);
plot(B1,f1, 'm', 'linewidth',1.25,Color='black');grid on;


p2 = polyfit(B2,C2,3);
f2 = polyval(p2,B2);
plot(B2,f2, 'm', 'linewidth',1.25,Color='black');grid on;


%% Plot given Tie lines

tiexc = [0.1 0.4];
tieyc = [0.1079 0.4944];
tiexb = [0.0021 0.0136];
tieyb = [0.8872 0.4751];

for i = 1:length(tiexc);
plot([tiexb(i) tieyb(i)],[tiexc(i) tieyc(i)],Color='magenta',LineWidth=1.25)
end


%% 2,3. Plot F,S, and M
%stages = input('enter number of stages:');
stages=1;
S = 800;
F = 1000;
xbf=0;
xcf=0.5;
ybs=0.995;
ycs=0.005;

plot([xbf ybs],[xcf ycs], 'g^-','linewidth',0.35,Color='cyan') % Line FS
text(xbf,xcf,' F')
text(ybs,ycs,' S')


tie_slope = zeros(1,length(tiexc));
for i = 1:length(tiexc)
tie_slope(i) = (tieyc(i)-tiexc(i))/(tieyb(i)-tiexb(i));
end

M = F + S;
Mx = (F*xbf + S*ybs)/M
My = (F*xcf + S*ycs)/M
plot(Mx,My,'o',Color='black') 
text(Mx,My,' M')



%% 3. Ploting Tie Line passing through M
if ((0 < My) && (My <= 0.1));
slope = 0 + (My-0)/(0.1-0)*tie_slope(1)
elseif((0.1 < My) && (My <= 0.4));
slope= tie_slope(1) + (My-0.1)/(0.4-0.1)*tie_slope(2)
elseif((My > 0.4));
slope= tie_slope(2) + (My-0.4)/(0.5-0.4)*1
end

%% 4. Solve Tie line and Fitted Polynomials for R and E
syms x y
[xbr,xcr] = vpasolve(y == p1(1)*x^5 + p1(2)*x^4 + p1(3)*x^3 + p1(4)*x^2 + p1(5)*x + p1(6),y == 0.28 + slope*(x-0.4422),x,y);
plot(xbr(1),xcr(1),'o',Color='black')
text(xbr(1),xcr(1),' R')

syms x y
[ybe,yce] = vpasolve(y == p2(1)*x^3 + p2(2)*x^2 + p2(3)*x + p2(4),y == 0.28 + slope*(x-0.4422),x,y);
plot(ybe(1),yce(1),'o',Color='black')
text(ybe(1),yce(1),'   E')

plot([xbr(1) ybe(1)],[xcr(1) yce(1)],Color='red',LineWidth=1.35)

 R = [ xbr(1) xcr(1)]
 E = [ybe(1) yce(1)]

%%  Amount of R and E
syms E R
[e,r] = vpasolve(E == M-R, E == R*((My-xcr(1))/(yce(1)-My)),E,R)

% fraction of solute separated from feed
solute_fraction = (yce(1)*e - ycs*S)/(F*xcf)
