clc
close all
clear

%% 1
yc=[0.0001 0.05 0.20 0.25 0.3 0.35 0.4 0.45 0.5];
ya=[0.0001 0.002 0.005 0.007 0.01 0.013 0.017 0.022 0.029];
xa=[0.67 0.66 0.64 0.625 0.60 0.58 0.55 0.51 0.46];

xc = ones(1,9);
xb = ones(1,9);
yb = ones(1,9);
mp = ones(1,9);
slope = ones(1,9);
figure(1)
for i=1:9
 yb(i)=1-ya(i)-yc(i);
 xc(i)=(yc(i)*(1-xa(i)))/(yc(i)+yb(i));
 xb(i)=1-xa(i)-xc(i);
 mp(i)=(yc(i)+xc(i))/2;
 slope(i)=(yb(i)-xb(i))/(yc(i)-xc(i));
 plot([xc(i) yc(i)],[xb(i) yb(i)])
 hold on; grid on;
end

Xc = ones(1,9);
Yc = ones(1,9);
z = ones(1,9);
Z = ones(1,9);

for i = 1:length(xc)
Xc(i) = xc(i)/(xb(i)+xc(i));
Z(i) = ya(i)/(yb(i)+yc(i));
Yc(i) = (yc(i))/(yc(i)+yb(i));
z(i) = xa(i)/(xb(i)+xc(i));
end

plot(xc,xb)
hold on;
plot(yc,yb)
hold on;

%% 2
F = 1000;
S = 1800;
yaf = 0.75;
ybf = 0.0;
ycf = 0.25;
xcs = 0.0;
xbs = 1.0;
xas = 0.0;

f = [ycf ybf];
s = [xcs xbs];
 plot([f(1) s(1)],[f(2) s(2)])
 text(ycf,ybf,'    F')
 text(xcs,xbs,'     S')
 hold on;

M = ones(1,10);
Mx = ones(1,10);
My = ones(1,10);
xbl = ones(1,10);
xcl = ones(1,10);
ycv = ones(1,10);
ybv = ones(1,10);
L = ones(1,10);
V = ones(1,10);


stages = 5;
S = ones(1,stages);

for i=1:5
    S(i)=1500;
end

p1=polyfit(xc,xb,2);
p2=polyfit(yc,yb,2);
slopeI = ones(1,10);

for i=1:stages
    if(i == 1)
        M(i) = F + S(i);
        Mx(i) = (F*ycf + S(i)*xcs)/M(i);
        My(i) = (F*ybf + S(i)*xbs)/M(i);
    elseif (i>1)
        M(i) = L(i-1) + S(i);
        Mx(i) = (L(i-1)*xcl(i-1) + S(i)*xcs)/M(i);
        My(i) = (L(i-1)*xbl(i-1) + S(i)*xbs)/M(i);
    end

%     plot(Mx(i),My(i),'o')
%     text(Mx(i),My(i),[' M'  num2str(i) ''])
    slopeI(i) = interp1(mp,slope,Mx(i),'linear');

    syms x y
    [xcl(i),xbl(i) ]= vpasolve([y==poly2sym(p1), y==My(i) + slopeI(i)*(x-Mx(i))],[x,y],[xc(1) xc(length(xc)); xb(length(xb)) xb(1)]);
    syms x y
    [ycv(i),ybv(i) ]= vpasolve([y==poly2sym(p2), y==My(i) + slopeI(i)*(x-Mx(i))],[x,y],[yc(1) yc(length(yc)) ; yb(length(yb)) yb(1)]);

    L(i)=(M(i)*Mx(i)-M(i)*ycv(i))/(xcl(i)-ycv(i));
    V(i)=M(i)-L(i);
end
for i= 1:stages
f3= plot([xcl(i) ycv(i)],[xbl(i) ybv(i)],'go-');
txt2 = ['L',num2str(i)];
text(xcl(i),xbl(i),txt2);
plot(xcl(i),xbl(i),'o');
txt3 = ['V',num2str(i)];
text(ycv(i),ybv(i),txt3);
plot(ycv(i),ybv(i),'o');
txt4 = ['M',num2str(i)];
text(Mx(i),My(i),txt4);
plot(Mx(i),My(i),'o');
end


figure(2)

    plot([1,2,3,4,5],ycv(1:5))
     legend('underflow')
    hold on;
    plot([1,2,3,4,5],xcl(1:5))
    title('overflow and underflow concentrations')
    legend('overflow')




