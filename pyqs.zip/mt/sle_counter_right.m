clc
clear
close all
%countercurrent operation
%given data
xb = [0.33 0.302 0.272 0.242 0.213 0.1817 0.1492 0.1148];
xc = [0 0.0336 0.0682 0.1039 0.1419 0.1817 0.224 0.268];
xa = 1-xb-xc;
yc = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.7];
yb = zeros(1,length(yc));
for i = 1: length(yc)
yb(i) = -yc(i) + 1;
end
ya = 1-yb-yc;
%plotting in right triangular system
figure(1)
plot([0 1 0 0], [0 0 1 0], 'k-', 'linewidth', 1.25); grid on; hold on;
plot(xc, xb, 'bo-'); grid on; hold on;
plot(yc, yb, 'bo-'); grid on; hold on;
xlabel('xC,yC'); ylabel('xB,yB');
title('Right-Angled Triangular System');

%plotting FS line
F1 = [0.26 0.005];
S1 = [0 0.995];
plot(F1, S1, 'go-');grid on; hold on;
text(0.26, 0.02, 'F');
text(0.02, 1, 'S');


p1 = polyfit(xb, xc, 1);
f1 = polyval(p1, xb);
p2 = polyfit(yb, yc, 1);
f2 = polyval(p2, yb);
tie_xb = xb;
tie_xc = xc;
tie_yb = yb;
tie_yc = yc;
%plotting the tie lines
for i = 1:length(tie_xb)
plot([tie_xc(i) tie_yc(i)],[tie_xb(i) tie_yb(i)], 'ro:');grid on; hold on;
end
tie_slope = ones(1, length(tie_xc));
 for i = 1:length(tie_xc)
tie_slope(i)=(yb(i)-xb(i))/(yc(i)-xc(i));
 end
%given data
S = 2100;
F = 2000;
xcf = 0.26;
xbf = 0;
ycs = 0.005;
ybs = 0.995;
xcr_n = 0.0015;
stage = 5;
%plotting the M point
M = F + S;
My = (F*xcf + S*ycs)/M;
Mx = (F*xbf + S*ybs)/M;
plot(My, Mx, 'bo')
text(My, Mx, 'M')
%finding V1 and extending V1 - F and S - L(n) to intersect at delta point
% Finding L(n) point: LN
syms x
xbr_n = vpasolve(xcr_n == poly2sym(p1, x), x, [0 1]);
xbr_n=double(xbr_n);
plot(xcr_n, xbr_n, 'bo')
text(xcr_n-0.01, xbr_n-0.01, 'LN')
R1 = [xbr_n Mx];
M1 = [xcr_n My];
slope_RnM = (xcr_n-My)/(xbr_n-Mx);
% % Finding the point V1
syms x y
[ybe_1, yce_1] = vpasolve([y ==poly2sym(p2), y == My + slope_RnM*(x-Mx)], [x,y], [0 1;0 1]);
plot([xcr_n yce_1], [xbr_n ybe_1],'c-');grid on; hold on;
ybe_1=double(ybe_1);
yce_1=double(yce_1);
text(yce_1, ybe_1, 'V1');
f1 = [0 ybe_1];
e1 = [0.26 yce_1];
p4 = polyfit(f1,e1, 1);
f4 = polyval(double(p4), f1);
r_n = [xbr_n 0.995];
s = [xcr_n 0.005];
p5 = polyfit(r_n,s, 1);
syms x y
[delta_x, delta_y] = vpasolve([y == poly2sym(p4), y == poly2sym(p5)], [x,y]);
plot([0.26 delta_y], [0 delta_x],'c-');grid on; hold on;
plot([xcr_n delta_y], [xbr_n delta_x],'c-');grid on; hold on;
% %calculating the amount of underflow and overflow after each stage
R = ones(1,stage);
E = ones(1,stage);
for i = 2:stage
syms x y
[A,B] = vpasolve([y == x+2, y ==x-22],[x y]);
end 

%tie line interpolation
for k =2:length(tie_yc)
if (yce_1 >= tie_yc(k-1) && yce_1 <= tie_yc(k))
break;
end
end
slope = tie_slope(k-1) + ((yce_1-tie_yc(k-1))/(tie_yc(k)-tie_yc(k-1))) * (tie_slope(k) - tie_slope(k-1));
% [xbr,xcr] = vpasolve([y == ............), ..................)],[x y],[0 1;0 1]);
% plot(xcr,xbr,'ko')
% plot([yce xcr],[ybe xbr],'m-')
% stage = stage + 1;
% text(xcr, xbr, ['L' num2str(stage) '']);
% text(yce, ybe, ['V' num2str(stage) '']);
% XBR(stage) = .......;
% XCR(stage) = ........;
% YBE(stage) = .......;
% YCE(stage) =...........;
% end
% N = stage;
% syms x y
% [RN E1] = vpasolve([y == ........- x, y ==..............],[x y]);
% R(N) = RN;
% E(1) = E1;
% %printing the results
% for i = 1:stage
% fprintf('Amount of underflow after stage_%d =', i);
% Disp(....);
% fprintf('Amount of overflow after stage_%d =', i);
% disp(.....));
% fprintf('Underflow concentration after stage_%d = ', i);
% disp(.....));
% fprintf('Overflow concentration after stage_%d = ', i);
% disp(.....));
% end
% 
% %calculating fractional recovery
% disp('Overall fraction of solute separated from the feed =')
% disp((E(1)*YCE(1) - S*ycs) / (F*xcf))