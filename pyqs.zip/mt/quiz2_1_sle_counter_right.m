clc
clear 
close all

% 1. A -  meal, B - hexane , C - Oil
% Right angled - counter current

%overflow - extract

yb = [99.7 90.6 84.54 74.47 69.46 60.44 54.45 44.46 38.5 34.55 24.63];
yc = [0 8.95 14.92 24.83 29.77 38.65 44.56 54.53 60.22 64.17 73.89];
ya = 1 - yb - yc;

%underflow - slurry

xb = [32.8 29.94 28.11 25.06 23.62 20.9 19.07 16.02 14.13 12.87 9.61];
xc = [0 2.96 4.96 8.36 10.12 13.35 15.6 19.59 22.10 23.90 28.85];
xa = 1- xb - xc;

ya = ya./100;
yb = yb./100;
yc = yc./100;
xa = xa./100;
xb = xb./100;
xc = xc./100;

mp = ones(1,length(yc));
slope = ones(1,length(yc));
figure(1)
plot(xc,xb)
hold on;
plot(yc,yb)
hold on;
for i=1:length(yc)
 mp(i)=(yc(i)+xc(i))/2;
 slope(i)=(yb(i)-xb(i))/(yc(i)-xc(i));
 plot([xc(i) yc(i)],[xb(i) yb(i)])
 hold on; grid on;
end
plot([0 1 0 0], [0 0 1 0], 'k-', 'linewidth', 1.25); grid on; hold on;
plot(xc, xb, 'bo-'); grid on; hold on;
plot(yc, yb, 'bo-'); grid on; hold on;
xlabel('xC,yC'); ylabel('xB,yB');
title('Right-Angled Triangular System');

%plotting FS line
F1 = [0.2 0.0];
S1 = [0 1];
plot(F1, S1, 'go-');grid on; hold on;
text(0.20, 0.0, 'F');
text(0.0, 1, 'S');


p1 = polyfit(xb, xc, 2);
f1 = polyval(p1, xb);
p2 = polyfit(yb, yc, 1);
f2 = polyval(p2, yb);
tie_xb = xb;
tie_xc = xc;
tie_yb = yb;
tie_yc = yc;
%plotting the tie lines
for i = 1:length(tie_xb)
plot([tie_xc(i) tie_yc(i)],[tie_xb(i) tie_yb(i)], 'ro:');grid on; hold on;
end
tie_slope = ones(1, length(tie_xc));
 for i = 1:length(tie_xc)
tie_slope(i)=(yb(i)-xb(i))/(yc(i)-xc(i));
 end

 %given data
S = 600;
F = 1000;
xcf = 0.2;
xbf = 0;
ycs = 0.0;
ybs = 1;
% stage = 5;
%plotting the M point
M = F + S;
My = (F*xcf + S*ycs)/M;
Mx = (F*xbf + S*ybs)/M;
plot(My, Mx, 'bo')
text(My, Mx, 'M')
%finding V1 and extending V1 - F and S - L(n) to intersect at delta point
% Finding L(n) point: LN
xcr_n = 0.01;
xbr_n = 0.329;
xbr_n=double(xbr_n);
plot(xcr_n, xbr_n, 'bo')
text(xcr_n, xbr_n, 'LN')
R1 = [xbr_n Mx];
M1 = [xcr_n My];
slope_RnM = (xcr_n-My)/(xbr_n-Mx);
% % Finding the point V1
syms x y
[ybe_1, yce_1] = vpasolve([y ==poly2sym(p2), y == My + slope_RnM*(x-Mx)], [x,y], [0 1;0 1]);
plot([xcr_n yce_1], [xbr_n ybe_1],'c-');grid on; hold on;
ybe_1=double(ybe_1);
yce_1=double(yce_1);
text(yce_1, ybe_1, 'V1');
f1 = [0 ybe_1];
e1 = [0.2 yce_1];
p4 = polyfit(f1,e1, 1);
f4 = polyval(double(p4), f1);
r_n = [xcr_n xbr_n];
s = [0 1];
slope_rns = (1-xbr_n)/(-xcr_n);
slope_fv = (yce_1-0)/(ybe_1-0.2);
syms x y
[delta_x, delta_y] = vpasolve([y == slope_fv*(x-0.2), y ==1 + slope_rns*(x)], [x,y])
plot([0.2 delta_x], [0 delta_y],'c-');grid on; hold on;
plot([xcr_n delta_x], [xbr_n delta_y],'c-');grid on; hold on;

for k =2:length(tie_yc)
if (yce_1 >= tie_yc(k-1) && yce_1 <= tie_yc(k))
break;
end
end
stage =1;
slope = tie_slope(k-1) + ((yce_1-tie_yc(k-1))/(tie_yc(k)-tie_yc(k-1))) * (tie_slope(k) - tie_slope(k-1));
syms x y
[xbr,xcr] = vpasolve([y == poly2sym(p1),y==ybe_1 + slope*(x-yce_1)],[x y],[0 1;0 1]);
% plot(xbr,xcr,'ko')
% plot([yce_1 xcr],[ybe_1 xbr],'m-')
text(xcr, xbr, ['L' num2str(1) '']);
text(yce_1, ybe_1, ['V' num2str(1) '']);

xcl = zeros(1,25);
xbl = zeros(1,25);
ybv = zeros(1,25);
ycv = zeros(1,25);

xcl(1) = xbr;
xbl(1) = xcr;
ycv(1) = yce_1;
ybv(1) = ybe_1;

i=1;

while xcl(i) > 0.01
    
    %plot([xcl(i) delta_x], [xbl(i) delta_y],'c-');grid on; hold on

    slope_RL = (xbl(i) - delta_y) / (xcl(i) - delta_x);
    syms x y
    [ycv(i+1),ybv(i+1)] = vpasolve([y==poly2sym(p2),y==delta_y+slope_RL*(x-delta_x)],[x,y],[0 1; 0 1]);
    text(ycv(i+1),ybv(i+1), ['V' num2str(i+1) '']);
    
    for k =2:length(tie_yc)
        if (ycv(i) >= tie_yc(k-1) && ycv(i) <= tie_yc(k))
            break;
        end
    end
    slope = tie_slope(k-1) + ((ycv(i)-tie_yc(k-1))/(tie_yc(k)-tie_yc(k-1))) * (tie_slope(k) - tie_slope(k-1));
    
    syms x y
    [xcl(i+1),xbl(i)] = vpasolve([y == poly2sym(p1),y==ybe_1 + slope*(x-yce_1)],[x y],[0 1;0 1]);
%     plot(xcl(i+1),xbl(i),'ko')
%     plot([yce_1 xcl(i+1)],[ybe_1 xbl(i+1)],'m-')
    text(xcl(i+1),xbl(i), ['L' num2str(i+1) '']);

%     plot([xcl(i+1) ycv(i+1)],[xbl(i+1) ybv(i+1)]);

    i=i+2;

end
disp("Number of stages:")
disp(i)