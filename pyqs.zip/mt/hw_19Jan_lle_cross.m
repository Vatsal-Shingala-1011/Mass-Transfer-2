clc
clear
close all

B = [0 0.004 0.006 0.01 0.02 0.03 0.036 0.07 0.13 0.16 0.19 0.23 0.26 0.5 0.63 0.71 0.78 0.84 0.9 0.95 1];
C = [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.4025 0.405 0.402 0.4 0.35 0.3 0.25 0.2 0.15 0.1 0.05 0];
A = 1 - B - C;
tiexc = [0.04 0.083 0.13 0.215 0.395];
tieyc = [0.035 0.068 0.09 0.145 0.31];

figure(1)
hold on;
B1 = zeros(1,10001);
C1 = zeros(1,10001);
for i = 1:10001
B1(i) = (i-1)/10000;
C1(i) = round(interp1(B,C, (i-1)/10000),4);
end
hold on;
plot(B1,C1,'b','linewidth',1.00);grid on;
hold on;
plot([0 1 0 0],[0 0 1 0],'k-.','linewidth',1.25)
xlabel('xB');ylabel('xC,yC');title('interpolated data - overall process schematic')

tiexb = zeros(1,length(tiexc));
tieyb = zeros(1,length(tiexc));
for i = 1:length(tiexc)
index1 = find(abs(C1-tiexc(i)) < 0.001,1,'first');
index2 =  find(abs(C1-tieyc(i)) < 0.001,1,'last');
XX = [B1(index1) B1(index2)] ;
YY = [tiexc(i) tieyc(i)];
tiexb(i) = XX(1);
tieyb(i)= XX(2);
plot(XX,YY,'mo:','linewidth',1.25);
end


tie_slope = zeros(1,length(tiexc));
for i = 1:length(tiexc)
tie_slope(i) = (tieyc(i)-tiexc(i))/(tieyb(i)-tiexb(i));

end


p1 = polyfit(B(1:10),C(1:10),5);
f1 = polyval(p1,B(1:10));
plot(B(1:10),f1, 'm', 'linewidth',1.25,Color='black');grid on;


p2 = polyfit(B(11:21),C(11:21),3);
f2 = polyval(p2,B(11:21));
plot(B(11:21),f2, 'm', 'linewidth',1.25,Color='black');grid on;


stages = 3;
S = [850 850 850];
F = 1000;
xbf = 0;
xcf = 0.35;
ybs = 0.98;
ycs = 0.02;

r = ones(1,stages);
e = ones(1,stages);
xbr = ones(1,stages);
xcr = ones(1,stages);
ybe = ones(1,stages);
yce = ones(1,stages);
M = ones(1, stages);
Mx = ones(1,stages);
My = ones(1, stages);
solute_fraction = ones(1,stages);

for i=1:stages
  M(i) = F + S(i);
Mx(i) = (F*xbf + S(i)*ybs)/M(i);
My(i) = (F*xcf + S(i)*ycs)/M(i);
plot(Mx(i),My(i),'o',Color='black') 
%text(Mx,My,' M')



if ((0 < My(i)) && (My(i) <= tiexc(1)))
slope = 0 + (My(i) - 0)*tie_slope(1)/(tiexc(1));
elseif((tiexc(1)< My(i)) && (My(i) <= tiexc(2)))
slope = tie_slope(1) + (My(i) - tiexc(1))*tie_slope(2)/(tiexc(2) - tiexc(1));
elseif ((tiexc(2) < My(i)) && (My(i) <= tiexc(3)))
slope = tie_slope(2) + (My(i) - tiexc(2))*tie_slope(3)/(tiexc(3) - tiexc(2));
elseif ((tiexc(3) < My(i)) && (My(i) <= tiexc(4)))
slope = tie_slope(3) + (My(i) - tiexc(3))*tie_slope(4)/(tiexc(4) - tiexc(3));
elseif ((tiexc(4) < My(i)) && (My(i) <= tiexc(5)))
slope = tie_slope(4) + (My(i) - tiexc(4))*tie_slope(5)/(tiexc(5) - tiexc(4));
elseif((My(i) > tiexc(5)))
slope = tie_slope(5) + (My(i) - tiexc(5))*(-0.155)/(0.5 - tiexc(5));
end

syms x y
[xbr(i),xcr(i)] = vpasolve([y==poly2sym(p1),y==My(i)+slope*(x-Mx(i))],[x,y],[0 0.2; 0 0.405]);
plot(xbr(i),xcr(i),'o',Color='black')
text(xbr(i),xcr(i),' R')

syms x y
[ybe(i),yce(i)] = vpasolve([y == poly2sym(p2),y == My(i) + slope*(x - Mx(i))],[x,y], [0.2 1; 0 0.405]);
plot(ybe(i),yce(i),'o',Color='black')
text(ybe(i),yce(i),'   E')

plot([xbr(i) ybe(i)],[xcr(i) yce(i)],Color='red',LineWidth=1.35)


syms E R
[e(i),r(i)] = vpasolve([E==M(i)-R,E==R*((My(i)-xcr(i))/(yce(i)-My(i)))],[E,R]);
%solute_fraction(i) = (yce(i)*e(i) - ycs*S)/(F*xcf)
F = r(i);
xbf=xbr(i);
xcf=xcr(i);

end